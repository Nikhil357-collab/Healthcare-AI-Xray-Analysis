import numpy as np
import matplotlib.pyplot as plt

from sklearn.metrics import (
    confusion_matrix,
    classification_report,
    ConfusionMatrixDisplay
)

from tensorflow.keras.models import load_model

from preprocess import test_data

# Load model
model = load_model("models/best_model.keras")

# Predictions
predictions = model.predict(test_data)

y_pred = (predictions > 0.5).astype(int)

y_true = test_data.classes

# Classification report
print(classification_report(y_true, y_pred))

# Confusion matrix
cm = confusion_matrix(y_true, y_pred)

disp = ConfusionMatrixDisplay(
    confusion_matrix=cm,
    display_labels=["NORMAL", "PNEUMONIA"]
)

disp.plot(cmap='Blues')

plt.title("Confusion Matrix")

plt.show()