from PIL import Image
import os

dataset_path = "AI_POWERED_MEDICAL_IMAGE ANALYSIS/dataset"

for root, dirs, files in os.walk(dataset_path):

    for file in files:

        path = os.path.join(root, file)

        try:
            img = Image.open(path)
            img.verify()

        except Exception as e:
            print("Corrupted Image:", path)
            os.remove(path)

print("Checking Completed")