from fastapi import FastAPI, File, UploadFile
from fastapi.responses import JSONResponse

import tensorflow as tf
import numpy as np
import cv2

app = FastAPI(title="AI Medical Image Analysis API")

# Load trained model
model = tf.keras.models.load_model(
    "AI_POWERED_MEDICAL_IMAGE_ANALYSIS/models/best_model.keras"
)

IMG_SIZE = 224

@app.get("/")
def home():

    return {
        "message": "AI Medical Image Analysis API Running"
    }

@app.post("/predict")
async def predict(file: UploadFile = File(...)):

    contents = await file.read()

    np_array = np.frombuffer(contents, np.uint8)

    image = cv2.imdecode(np_array, cv2.IMREAD_COLOR)

    image = cv2.resize(image, (IMG_SIZE, IMG_SIZE))

    image = image / 255.0

    image = np.expand_dims(image, axis=0)

    prediction = model.predict(image)[0][0]

    confidence = float(prediction)

    if prediction > 0.5:
        result = "PNEUMONIA"
    else:
        result = "NORMAL"

    return JSONResponse({
        "prediction": result,
        "confidence": confidence
    })