import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load trained model
model = load_model(
    "AI_POWERED_MEDICAL_IMAGE_ANALYSIS/models/multidisease_model.keras"
)

# Disease class names
class_names = [
    "COVID",
    "NORMAL",
    "PNEUMONIA",
    "TB"
]

# Image path
image_path = "AI_POWERED_MEDICAL_IMAGE_ANALYSIS\\dataset\\test\\TB\\Tuberculosis-116.png"

# Read image
image = cv2.imread(image_path)

# Check image
if image is None:
    print("ERROR: Image not found")
    exit()

# Resize
image = cv2.resize(image, (224,224))

# Normalize
image = image / 255.0

# Reshape
image = np.expand_dims(image, axis=0)

# Predict
prediction = model.predict(image)

# Get highest probability index
predicted_index = np.argmax(prediction)

# Get disease name
predicted_class = class_names[predicted_index]

# Confidence
confidence = prediction[0][predicted_index]

# Output
print("Prediction:", predicted_class)

print("Confidence:", round(confidence * 100, 2), "%")

# Show all class probabilities
print("\nClass Probabilities:")

for i, disease in enumerate(class_names):

    prob = prediction[0][i] * 100

    print(f"{disease}: {prob:.2f}%")