from PIL import ImageFile
from tensorflow.keras.preprocessing.image import ImageDataGenerator
ImageFile.LOAD_TRUNCATED_IMAGES = True
IMG_SIZE = (224, 224)
BATCH_SIZE = 32

# Training augmentation
train_datagen = ImageDataGenerator(
    rescale=1./255,

    rotation_range=20,

    zoom_range=0.2,

    horizontal_flip=True,

    brightness_range=[0.8,1.2],

    width_shift_range=0.1,

    height_shift_range=0.1
)

# Validation/Test preprocessing
test_datagen = ImageDataGenerator(
    rescale=1./255
)

# Training data
train_data = train_datagen.flow_from_directory(
    "AI_POWERED_MEDICAL_IMAGE_ANALYSIS\\dataset\\train",
    target_size=IMG_SIZE,
    color_mode='rgb',
    batch_size=BATCH_SIZE,
    class_mode='binary'
)

# Validation data
val_data = test_datagen.flow_from_directory(
    "AI_POWERED_MEDICAL_IMAGE_ANALYSIS\\dataset\\validation",
    target_size=IMG_SIZE,
    color_mode='rgb',
    batch_size=BATCH_SIZE,
    class_mode='binary'
)

# Test data
test_data = test_datagen.flow_from_directory(
    "AI_POWERED_MEDICAL_IMAGE_ANALYSIS\\dataset\\test",
    target_size=IMG_SIZE,
    color_mode='rgb',
    batch_size=BATCH_SIZE,
    class_mode='binary',
    shuffle=False
)

print("Classes:", train_data.class_indices)